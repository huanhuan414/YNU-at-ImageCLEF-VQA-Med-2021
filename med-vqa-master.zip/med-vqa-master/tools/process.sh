# Process data

python create_dictionary.py
python create_label.py
